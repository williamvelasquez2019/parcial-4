use hospital
GO

select * from Doctor
select * from Emp
select * from Enfermo
select * from Plantilla
select * from hospital.Sala