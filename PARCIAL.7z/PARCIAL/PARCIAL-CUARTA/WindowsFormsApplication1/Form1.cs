﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        static SqlDataAdapter Adaptador = new SqlDataAdapter();
        static SqlConnection Conectar = new SqlConnection();
        static SqlCommandBuilder GeneradorComando;
        static SqlCommand Comando = new SqlCommand();
        private string consultaSQL;
        private string cadena_conx = "Data Source=.;Initial Catalog=hospital;Integrated Security=True";

        public void insertarFull()
        {
            Conexion obj = new Conexion();
            string sentencia = "INSERT INTO Doctor  VALUES('"textBox1.Text+ textBox2.Text+ textBox3.Text+textBox4.Text"')";

            try
            {
                obj.Conectar();
            }
            catch
            {

            }

        }

        public void setConsultasSql(string consulta)
        {
            consultaSQL = consulta;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertarDatos();
        }
        public void InsertarDatos() 
        {
            try
            {
                Comando = new SqlCommand(consultaSQL, Conectar);
                Comando.ExecuteNonQuery();
            }
            catch (System.IO.IOException ex)
            {
                MessageBox.Show("Error al ejecutar el insert"+ ex.Message);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            InsertarDatos();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            InsertarDatos();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            InsertarDatos();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            InsertarDatos();
        }
    }
}
